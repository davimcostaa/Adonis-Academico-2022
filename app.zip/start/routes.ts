
import Route from '@ioc:Adonis/Core/Route'

Route.get('/', async () => {
  return { hello: 'world' }
})

Route.get('/teste', async () => {
  return { hello: 'teste' }
})

Route.get('/cursos', 'CursosController.index')
Route.post('/cursos', 'CursosController.store')
